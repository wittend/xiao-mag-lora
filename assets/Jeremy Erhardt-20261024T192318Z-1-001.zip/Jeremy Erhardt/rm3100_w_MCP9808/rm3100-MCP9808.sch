EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr USLetter 11000 8500
encoding utf-8
Sheet 1 1
Title "RM3100 Magnetometer w/ MCP9808 Temp sensor"
Date "2019-12-19"
Rev "0.0.02"
Comp "WWR Development, LLC"
Comment1 ""
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L Connector_Generic:Conn_01x04 Conn1
U 1 1 5DB4A1AA
P 1300 2125
F 0 "Conn1" H 1300 1800 50  0000 C CNN
F 1 "Qwiic_01x04" H 1300 2350 50  0000 C CNN
F 2 "Connector_JST:JST_SH_SM04B-SRSS-TB_1x04-1MP_P1.00mm_Horizontal" H 1300 2125 50  0001 C CNN
F 3 "https://cdn.sparkfun.com/assets/parts/1/2/2/8/9/Qwiic_Connector_Datasheet.pdf" H 1300 2125 50  0001 C CNN
F 4 "N.A." H 1300 2125 50  0001 C CNN "Digikey Part #"
F 5 "‎SM04B-SRSS-TB" H 1300 2125 50  0001 C CNN "Mfg Part #"
	1    1300 2125
	-1   0    0    1   
$EndComp
Wire Wire Line
	5575 1875 5250 1875
$Comp
L power:GND #PWR012
U 1 1 5DC9EFB6
P 4825 2725
F 0 "#PWR012" H 4825 2475 50  0001 C CNN
F 1 "GND" H 4830 2552 50  0000 C CNN
F 2 "" H 4825 2725 50  0001 C CNN
F 3 "" H 4825 2725 50  0001 C CNN
	1    4825 2725
	1    0    0    -1  
$EndComp
Text GLabel 5250 1875 0    50   Input ~ 0
SCL
Wire Wire Line
	5575 2075 5250 2075
Text GLabel 5250 2075 0    50   Input ~ 0
SDA
Wire Wire Line
	6475 2275 6725 2275
Wire Wire Line
	6475 2075 6725 2075
Wire Wire Line
	6475 1975 6725 1975
Wire Wire Line
	1500 2225 1750 2225
Wire Wire Line
	1750 2225 1750 2475
$Comp
L power:GND #PWR01
U 1 1 5DD5200C
P 1750 2475
F 0 "#PWR01" H 1750 2225 50  0001 C CNN
F 1 "GND" H 1755 2302 50  0000 C CNN
F 2 "" H 1750 2475 50  0001 C CNN
F 3 "" H 1750 2475 50  0001 C CNN
	1    1750 2475
	1    0    0    -1  
$EndComp
$Comp
L Connector_Generic:Conn_01x04 Conn2
U 1 1 5DD8296B
P 2550 2125
F 0 "Conn2" H 2525 1800 50  0000 C CNN
F 1 "Qwiic_01x04" H 2468 2351 50  0000 C CNN
F 2 "Connector_JST:JST_SH_SM04B-SRSS-TB_1x04-1MP_P1.00mm_Horizontal" H 2550 2125 50  0001 C CNN
F 3 "https://cdn.sparkfun.com/assets/parts/1/2/2/8/9/Qwiic_Connector_Datasheet.pdf" H 2550 2125 50  0001 C CNN
F 4 "N.A." H 2550 2125 50  0001 C CNN "Digikey Part #"
F 5 "‎SM04B-SRSS-TB" H 2550 2125 50  0001 C CNN "Mfg Part #"
	1    2550 2125
	-1   0    0    1   
$EndComp
Wire Wire Line
	2750 2225 3000 2225
Wire Wire Line
	3000 2225 3000 2475
Wire Wire Line
	2750 2125 3150 2125
Wire Wire Line
	2750 2025 3150 2025
Wire Wire Line
	2750 1925 3150 1925
$Comp
L power:GND #PWR06
U 1 1 5DD82976
P 3000 2475
F 0 "#PWR06" H 3000 2225 50  0001 C CNN
F 1 "GND" H 3005 2302 50  0000 C CNN
F 2 "" H 3000 2475 50  0001 C CNN
F 3 "" H 3000 2475 50  0001 C CNN
	1    3000 2475
	1    0    0    -1  
$EndComp
Text GLabel 3150 1925 2    50   Input ~ 0
SCL
Text GLabel 3150 2025 2    50   Input ~ 0
SDA
$Comp
L power:+3.3V #PWR07
U 1 1 5DD8297E
P 3150 2125
F 0 "#PWR07" H 3150 1975 50  0001 C CNN
F 1 "+3.3V" V 3165 2253 50  0000 L CNN
F 2 "" H 3150 2125 50  0001 C CNN
F 3 "" H 3150 2125 50  0001 C CNN
	1    3150 2125
	0    1    -1   0   
$EndComp
Wire Wire Line
	6650 5775 7300 5775
$Comp
L Device:C_Small C1
U 1 1 5DF93E86
P 7300 4725
F 0 "C1" H 7415 4771 50  0000 L CNN
F 1 "1.0uF" H 7415 4680 50  0000 L CNN
F 2 "Capacitor_SMD:C_0805_2012Metric" H 7338 4575 50  0001 C CNN
F 3 "https://api.kemet.com/component-edge/download/datasheet/C0805C105K8RACTU.pdf" H 7300 4725 50  0001 C CNN
F 4 "399-1172-1-ND" H 7300 4725 50  0001 C CNN "Digikey Part #"
F 5 "C0805C105K8RACTU" H 7300 4725 50  0001 C CNN "Mfg Part #"
	1    7300 4725
	1    0    0    -1  
$EndComp
Wire Wire Line
	7300 4625 7300 4500
Text Notes 9250 6975 2    50   ~ 0
Released under the Creative Commons Attribution Share-Alike 4.0 License \nhttps://creativecommons.org/licenses/by-sa/4.0/
Text Notes 7775 7275 2    50   ~ 0
Design by: Dave Witten 2019-12-19
$Comp
L Jumper:SolderJumper_3_Bridged123 JP1
U 1 1 5E005CA3
P 8850 2800
F 0 "JP1" H 8850 3005 50  0000 C CNN
F 1 "Pullup Resistors" H 8850 3625 50  0000 C CNN
F 2 "basic-rm3100:SolderJumper-3_P1.3mm_Bridged123_RoundedPad1.0x1.5mm" H 8850 2800 50  0001 C CNN
F 3 "N.A." H 8850 2800 50  0001 C CNN
F 4 "N.A." H 8850 2800 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 8850 2800 50  0001 C CNN "Mfg Part #"
	1    8850 2800
	1    0    0    1   
$EndComp
Wire Wire Line
	8300 2800 8650 2800
Wire Wire Line
	9050 2800 9400 2800
Wire Wire Line
	8850 2650 8850 2450
$Comp
L Device:R_Small_US R1
U 1 1 5E01D412
P 8300 3100
F 0 "R1" H 8368 3146 50  0000 L CNN
F 1 "4.7K" H 8368 3055 50  0000 L CNN
F 2 "Resistor_SMD:R_0805_2012Metric" H 8300 3100 50  0001 C CNN
F 3 "https://www.yageo.com/upload/media/product/productsearch/datasheet/rchip/PYu-RC_Group_51_RoHS_L_10.pdf" H 8300 3100 50  0001 C CNN
F 4 "RC0805FR-074K7L‎ " H 8300 3100 50  0001 C CNN "Mfg Part #"
F 5 "311-4.70KCRCT-ND" H 8300 3100 50  0001 C CNN "Digikey Part #"
	1    8300 3100
	1    0    0    -1  
$EndComp
$Comp
L Device:R_Small_US R2
U 1 1 5E020EB0
P 9400 3100
F 0 "R2" H 9468 3146 50  0000 L CNN
F 1 "4.7K" H 9468 3055 50  0000 L CNN
F 2 "Resistor_SMD:R_0805_2012Metric" H 9400 3100 50  0001 C CNN
F 3 "https://www.yageo.com/upload/media/product/productsearch/datasheet/rchip/PYu-RC_Group_51_RoHS_L_10.pdf" H 9400 3100 50  0001 C CNN
F 4 "RC0805FR-074K7L‎ " H 9400 3100 50  0001 C CNN "Mfg Part #"
F 5 "311-4.70KCRCT-ND" H 9400 3100 50  0001 C CNN "Digikey Part #"
	1    9400 3100
	1    0    0    -1  
$EndComp
Wire Wire Line
	8300 2800 8300 3000
Wire Wire Line
	9400 2800 9400 3000
Wire Wire Line
	8300 3200 8300 3450
Wire Wire Line
	9400 3200 9400 3450
Text GLabel 9400 3450 2    50   Input ~ 0
SCL
Text GLabel 8300 3450 0    50   Input ~ 0
SDA
$Comp
L rm3100-MCP9808-rescue:PNI-RM3100mag-Interface U1
U 1 1 5DCF9A12
P 6025 2075
F 0 "U1" H 6025 2500 50  0000 C CNN
F 1 "PNI-RM3100mag" H 6025 2409 50  0000 C CNN
F 2 "pni_rm3100:PinSocket_PNI_RM3100" H 6025 2425 50  0001 C CNN
F 3 "https://www.pnicorp.com/download/rm3100-user-manual/RM3100-Sensor-Suite-User-Manual-R07-1.pdf" H 6025 2425 50  0001 C CNN
F 4 "N.A." H 6025 2075 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 6025 2075 50  0001 C CNN "Mfg Part #"
	1    6025 2075
	1    0    0    -1  
$EndComp
Wire Wire Line
	5575 2475 4825 2475
Wire Wire Line
	4825 2475 4825 2725
$Comp
L Graphic:Logo_Open_Hardware_Small #LOGO1
U 1 1 5DF47832
P 10200 7125
F 0 "#LOGO1" H 10200 7400 50  0001 C CNN
F 1 "Logo_Open_Hardware_Small" H 10200 6900 50  0001 C CNN
F 2 "" H 10200 7125 50  0001 C CNN
F 3 "~" H 10200 7125 50  0001 C CNN
	1    10200 7125
	1    0    0    -1  
$EndComp
Wire Wire Line
	6725 2075 6825 2075
$Comp
L power:+3.3V #PWR017
U 1 1 5DD8A7F1
P 6825 2075
F 0 "#PWR017" H 6825 1925 50  0001 C CNN
F 1 "+3.3V" V 6840 2203 50  0000 L CNN
F 2 "" H 6825 2075 50  0001 C CNN
F 3 "" H 6825 2075 50  0001 C CNN
	1    6825 2075
	0    1    1    0   
$EndComp
NoConn ~ 5575 2275
Wire Wire Line
	4825 1975 4825 2175
$Comp
L power:+3.3V #PWR05
U 1 1 5DF7A48E
P 8850 2450
F 0 "#PWR05" H 8850 2300 50  0001 C CNN
F 1 "+3.3V" H 8865 2623 50  0000 C CNN
F 2 "" H 8850 2450 50  0001 C CNN
F 3 "" H 8850 2450 50  0001 C CNN
	1    8850 2450
	1    0    0    -1  
$EndComp
Wire Wire Line
	6725 2275 6725 2075
Connection ~ 6725 2075
Wire Wire Line
	6725 1975 6725 2075
Wire Wire Line
	4825 1975 5575 1975
Wire Wire Line
	4825 2175 5575 2175
Wire Wire Line
	6475 1875 6625 1875
Wire Wire Line
	6625 1875 6625 1525
Wire Wire Line
	6625 1525 4825 1525
Wire Wire Line
	4825 1525 4825 1975
Connection ~ 4825 1975
Wire Wire Line
	4825 2175 4825 2475
Connection ~ 4825 2175
Connection ~ 4825 2475
$Comp
L Mechanical:MountingHole H1
U 1 1 5E1BE6B8
P 675 675
F 0 "H1" H 775 721 50  0000 L CNN
F 1 "MountingHole" H 775 630 50  0000 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_ISO7380" H 675 675 50  0001 C CNN
F 3 "Do not populate" H 675 675 50  0001 C CNN
F 4 "N.A." H 675 675 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 675 675 50  0001 C CNN "Mfg Part #"
	1    675  675 
	1    0    0    -1  
$EndComp
$Comp
L Mechanical:MountingHole H2
U 1 1 5E1CB888
P 700 7850
F 0 "H2" H 800 7896 50  0000 L CNN
F 1 "MountingHole" H 800 7805 50  0000 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_ISO7380" H 700 7850 50  0001 C CNN
F 3 "Do not populate" H 700 7850 50  0001 C CNN
F 4 "N.A." H 700 7850 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 700 7850 50  0001 C CNN "Mfg Part #"
	1    700  7850
	1    0    0    -1  
$EndComp
NoConn ~ 11600 5500
Text Notes 5300 2750 0    50   ~ 0
Magnetometer Module
Text Notes 1575 2875 0    50   ~ 0
Qwiic / Stemma-QT Connectors
Text GLabel 1675 2025 2    50   Input ~ 0
SDA
Wire Wire Line
	1500 2025 1675 2025
Text GLabel 1675 1925 2    50   Input ~ 0
SCL
Wire Wire Line
	1500 1925 1675 1925
Wire Wire Line
	1500 2125 2000 2125
Wire Wire Line
	2000 2125 2000 1750
$Comp
L power:+3.3V #PWR04
U 1 1 5DD5F1E2
P 2000 1750
F 0 "#PWR04" H 2000 1600 50  0001 C CNN
F 1 "+3.3V" V 2000 1875 50  0000 L CNN
F 2 "" H 2000 1750 50  0001 C CNN
F 3 "" H 2000 1750 50  0001 C CNN
	1    2000 1750
	-1   0    0    -1  
$EndComp
$Comp
L Sensor_Temperature:MCP9804_MSOP U2
U 1 1 5DE992F7
P 6650 5225
F 0 "U2" H 6825 5775 50  0000 L CNN
F 1 "MCP9808" H 6025 5775 50  0000 L CNN
F 2 "basic-rm3100:MCP9808_MSOPx8x0.65" H 5650 4725 50  0001 C CNN
F 3 "https://www.microchip.com/mymicrochip/filehandler.aspx?ddocname=en556196" H 6400 5675 50  0001 C CNN
F 4 "MCP9808T-E/MS" H 6650 5225 50  0001 C CNN "Digikey Part #"
F 5 "MCP9808T-E/MS" H 6650 5225 50  0001 C CNN "Mfg Part #"
	1    6650 5225
	1    0    0    -1  
$EndComp
$Comp
L power:GND #PWR015
U 1 1 5DF3E500
P 6650 5900
F 0 "#PWR015" H 6650 5650 50  0001 C CNN
F 1 "GND" H 6655 5727 50  0000 C CNN
F 2 "" H 6650 5900 50  0001 C CNN
F 3 "" H 6650 5900 50  0001 C CNN
	1    6650 5900
	1    0    0    -1  
$EndComp
$Comp
L power:+3.3V #PWR016
U 1 1 5DF55DC8
P 6650 4275
F 0 "#PWR016" H 6650 4125 50  0001 C CNN
F 1 "+3.3V" H 6665 4448 50  0000 C CNN
F 2 "" H 6650 4275 50  0001 C CNN
F 3 "" H 6650 4275 50  0001 C CNN
	1    6650 4275
	1    0    0    -1  
$EndComp
Wire Wire Line
	6650 4275 6650 4500
Text GLabel 6125 4925 0    50   Input ~ 0
SDA
Text GLabel 6125 5025 0    50   Input ~ 0
SCL
Wire Wire Line
	6125 4925 6250 4925
Wire Wire Line
	6250 5025 6125 5025
Wire Wire Line
	5625 5325 6250 5325
Wire Wire Line
	5625 5325 5625 4775
Wire Wire Line
	5625 4775 5550 4775
Wire Wire Line
	6650 5725 6650 5775
$Comp
L basic-rm3100-rescue:SolderJumper_3_Bridged12-Jumper PJ2
U 1 1 5E3D8A9E
P 4500 4775
F 0 "PJ2" H 4625 4875 50  0000 C CNN
F 1 "A2" H 4425 4875 50  0000 C CNN
F 2 "Jumper:SolderJumper-3_P1.3mm_Bridged12_RoundedPad1.0x1.5mm" H 4500 4775 50  0001 C CNN
F 3 "N.A." H 4500 4775 50  0001 C CNN
F 4 "N.A." H 4500 4775 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 4500 4775 50  0001 C CNN "Mfg Part #"
	1    4500 4775
	0    -1   -1   0   
$EndComp
$Comp
L power:PWR_FLAG #FLG02
U 1 1 5E36AC9B
P 6650 5900
F 0 "#FLG02" H 6650 5975 50  0001 C CNN
F 1 "PWR_FLAG" V 6650 6028 50  0000 L CNN
F 2 "" H 6650 5900 50  0001 C CNN
F 3 "~" H 6650 5900 50  0001 C CNN
	1    6650 5900
	0    1    1    0   
$EndComp
NoConn ~ 7050 5225
$Comp
L Device:R_Small R4
U 1 1 5DFD7EAC
P 4950 5150
F 0 "R4" H 5009 5196 50  0000 L CNN
F 1 "10k" H 5009 5105 50  0000 L CNN
F 2 "Resistor_SMD:R_0805_2012Metric" H 4950 5150 50  0001 C CNN
F 3 "~" H 4950 5150 50  0001 C CNN
	1    4950 5150
	1    0    0    -1  
$EndComp
$Comp
L Device:R_Small R5
U 1 1 5E04948F
P 5400 5150
F 0 "R5" H 5459 5196 50  0000 L CNN
F 1 "10k" H 5459 5105 50  0000 L CNN
F 2 "Resistor_SMD:R_0805_2012Metric" H 5400 5150 50  0001 C CNN
F 3 "~" H 5400 5150 50  0001 C CNN
	1    5400 5150
	1    0    0    -1  
$EndComp
Wire Wire Line
	5400 5250 5400 5775
Wire Wire Line
	5400 5050 5400 4975
Wire Wire Line
	4500 4500 4950 4500
Connection ~ 6650 4500
Wire Wire Line
	6650 4500 6650 4725
Wire Wire Line
	4950 4500 5400 4500
Connection ~ 4950 4500
Wire Wire Line
	4950 5250 4950 5775
Wire Wire Line
	4500 4500 4500 4575
$Comp
L Device:R_Small R3
U 1 1 5E18CCB8
P 4500 5150
F 0 "R3" H 4559 5196 50  0000 L CNN
F 1 "10k" H 4559 5105 50  0000 L CNN
F 2 "Resistor_SMD:R_0805_2012Metric" H 4500 5150 50  0001 C CNN
F 3 "~" H 4500 5150 50  0001 C CNN
	1    4500 5150
	1    0    0    -1  
$EndComp
Wire Wire Line
	4500 4975 4500 5050
$Comp
L basic-rm3100-rescue:SolderJumper_3_Bridged12-Jumper PJ0
U 1 1 5E1907BA
P 5400 4775
F 0 "PJ0" H 5525 4875 50  0000 C CNN
F 1 "A0" H 5325 4875 50  0000 C CNN
F 2 "Jumper:SolderJumper-3_P1.3mm_Bridged12_RoundedPad1.0x1.5mm" H 5400 4775 50  0001 C CNN
F 3 "N.A." H 5400 4775 50  0001 C CNN
F 4 "N.A." H 5400 4775 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 5400 4775 50  0001 C CNN "Mfg Part #"
	1    5400 4775
	0    -1   -1   0   
$EndComp
Wire Wire Line
	4500 5250 4500 5775
Wire Wire Line
	4725 5525 4725 4775
Wire Wire Line
	5400 4575 5400 4500
Connection ~ 5400 4500
Wire Wire Line
	5400 4500 6650 4500
Wire Wire Line
	4950 4500 4950 4575
Wire Wire Line
	4950 4975 4950 5050
Wire Wire Line
	6250 5425 5175 5425
$Comp
L basic-rm3100-rescue:SolderJumper_3_Bridged12-Jumper PJ1
U 1 1 5E3CA3C2
P 4950 4775
F 0 "PJ1" H 5075 4875 50  0000 C CNN
F 1 "A1" H 4875 4875 50  0000 C CNN
F 2 "Jumper:SolderJumper-3_P1.3mm_Bridged12_RoundedPad1.0x1.5mm" H 4950 4775 50  0001 C CNN
F 3 "N.A." H 4950 4775 50  0001 C CNN
F 4 "N.A." H 4950 4775 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 4950 4775 50  0001 C CNN "Mfg Part #"
	1    4950 4775
	0    -1   -1   0   
$EndComp
Wire Wire Line
	5175 4775 5175 5425
Wire Wire Line
	4500 5775 4950 5775
Wire Wire Line
	4950 5775 5400 5775
Connection ~ 4950 5775
Wire Wire Line
	5400 5775 6650 5775
Connection ~ 5400 5775
Wire Wire Line
	6650 5775 6650 5900
Connection ~ 6650 5775
Wire Wire Line
	7300 4500 6650 4500
Wire Wire Line
	4725 4775 4650 4775
Wire Wire Line
	4725 5525 6250 5525
Wire Wire Line
	5100 4775 5175 4775
Wire Wire Line
	7300 5775 7300 4825
$Comp
L Mechanical:MountingHole H4
U 1 1 5E2E0463
P 10350 600
F 0 "H4" H 10450 646 50  0000 L CNN
F 1 "MountingHole" H 10450 555 50  0001 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_ISO7380" H 10350 600 50  0001 C CNN
F 3 "Do not populate" H 10350 600 50  0001 C CNN
F 4 "N.A." H 10350 600 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 10350 600 50  0001 C CNN "Mfg Part #"
	1    10350 600 
	1    0    0    -1  
$EndComp
$Comp
L Mechanical:MountingHole H3
U 1 1 5E2E2FA6
P 10300 6575
F 0 "H3" H 10400 6621 50  0000 L CNN
F 1 "MountingHole" H 10400 6530 50  0000 L CNN
F 2 "MountingHole:MountingHole_3.2mm_M3_ISO7380" H 10300 6575 50  0001 C CNN
F 3 "Do not populate" H 10300 6575 50  0001 C CNN
F 4 "N.A." H 10300 6575 50  0001 C CNN "Digikey Part #"
F 5 "N.A." H 10300 6575 50  0001 C CNN "Mfg Part #"
	1    10300 6575
	1    0    0    -1  
$EndComp
$EndSCHEMATC
